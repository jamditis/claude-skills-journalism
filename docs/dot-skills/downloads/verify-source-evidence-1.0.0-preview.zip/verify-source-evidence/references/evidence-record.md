# Evidence record template

Use one record per precise claim. Keep it as short as the stakes allow. Mark unknown fields explicitly rather than inventing them.

**Claim:** Exact wording; subject, environment/population, time period.
**Claim source:** Creator, original URL or authorized artifact reference, relevant context.
**Dates:** Published / effective / observed / accessed; timezone.
**Evidence checked:**

| Source and direct locator | Provenance and independence | What it establishes | Limits, dates, revision/role if relevant |
|---|---|---|---|
| ... | ... | ... | ... |

**Supporting evidence:** ...
**Conflicting evidence:** ...
**Missing or inaccessible evidence:** ...
**Actions actually performed:** Read / compared / calculated / inspected; distinguish external receipts from tests personally run.
**Assessment:** Verified / supported with limits / unresolved / contradicted / inauthentic.
**Reasoning and narrower defensible wording:** ...
**What would change the result:** ...
**Checked by and assessment time:** ...
**Preservation:** Existing authorized saved artifact and hash if available, or not saved. Do not include private locators in public versions.

## Small example

Claim: "The new preview feature works for editors now."
Evidence: A merged source change today; yesterday's administrator success receipt; no deployment revision or ordinary-editor acceptance receipt.
Assessment: Unresolved for the stated claim. The narrower supported statement is that implementation merged; today's deployment and editor behavior are unverified. Do not call the service unavailable on this evidence alone, and do not run a production test without authorization.
