# Source provenance

Derived from Joe Amditis's MIT-licensed source-verification skill:
https://github.com/jamditis/claude-skills-journalism/tree/5dedab1cd3ede800b85cb6cd1943865ef96f5fd6/journalism-core/skills/source-verification

Source files consulted: SKILL.md, references/source-credibility.md, and references/verification-trail-and-archiving.md. Original copyright: 2025 Joe Amditis. The full MIT notice is retained in ../LICENSE.

Dot adaptation, October 29, 2026: retain SIFT, source/claim distinction, evidence conflicts, provenance, and a verification trail; replace assumed tool integrations with capability discovery; remove automatic public-archive submissions and CLI dependencies; add permission-aware preservation, exact temporal scope, repository/deployment/runtime/role distinctions, and conservative assessment labels. No hooks, credentials, private account identifiers, or external-service dependencies are bundled.
